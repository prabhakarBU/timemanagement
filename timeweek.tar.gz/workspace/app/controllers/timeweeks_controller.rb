class TimeweeksController < ApplicationController
  def index
  end
end
