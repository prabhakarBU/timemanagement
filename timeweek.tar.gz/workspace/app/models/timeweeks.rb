class Timeweek < ActiveRecord::Base
end
